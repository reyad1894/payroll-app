import React from 'react'
import ReactDOM from 'react-dom/client'
import PayrollApp from './PayrollApp'
import './style.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PayrollApp />
  </React.StrictMode>
)
