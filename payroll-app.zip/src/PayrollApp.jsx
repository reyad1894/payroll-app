import React, { useState } from 'react';

const labels = {
  en: {
    title: "Payroll Calculator",
    name: "Name",
    hours: "Working Hours",
    baseSalary: "Base Salary (₩)",
    electricity: "Electricity Cost (₩)",
    gas: "Gas Cost (₩)",
    housing: "Housing Cost (₩)",
    calculate: "Calculate Salary",
    result: "Salary Breakdown",
    tax: "Tax (3.3%)",
    safety: "Safety Insurance Deduction",
    net: "Net Salary (₩)"
  },
  ar: {
    title: "حاسبة الرواتب",
    name: "الاسم",
    hours: "ساعات العمل",
    baseSalary: "الراتب الأساسي (₩)",
    electricity: "تكلفة الكهرباء (₩)",
    gas: "تكلفة الغاز (₩)",
    housing: "تكلفة السكن (₩)",
    calculate: "احسب الراتب",
    result: "تفاصيل الراتب",
    tax: "الضريبة (3.3%)",
    safety: "خصم تأمين السلامة",
    net: "صافي الراتب (₩)"
  },
  ko: {
    title: "급여 계산기",
    name: "이름",
    hours: "근무 시간",
    baseSalary: "기본 급여 (₩)",
    electricity: "전기 요금 (₩)",
    gas: "가스 요금 (₩)",
    housing: "주택 비용 (₩)",
    calculate: "급여 계산",
    result: "급여 내역",
    tax: "세금 (3.3%)",
    safety: "안전 보험 공제",
    net: "실수령 급여 (₩)"
  }
};

export default function PayrollApp() {
  const [lang, setLang] = useState('ar');
  const [data, setData] = useState({ name: '', hours: 10, base: 0, electricity: 0, gas: 0, housing: 0 });
  const [result, setResult] = useState(null);

  const l = labels[lang];

  const handleCalc = () => {
    const tax = 0.033 * data.base;
    const safety = 23000;
    const totalDeductions = tax + safety + Number(data.electricity) + Number(data.gas) + Number(data.housing);
    const net = data.base - totalDeductions;
    setResult({ tax, safety, totalDeductions, net });
  };

  return (
    <div style={{ padding: '20px', backgroundColor: '#fff', maxWidth: '800px', margin: 'auto' }}>
      <h1>{l.title}</h1>
      <select value={lang} onChange={e => setLang(e.target.value)}>
        <option value="ar">العربية</option>
        <option value="en">English</option>
        <option value="ko">한국어</option>
      </select>
      <input placeholder={l.name} onChange={e => setData({ ...data, name: e.target.value })} />
      <input type="number" placeholder={l.hours} onChange={e => setData({ ...data, hours: e.target.value })} />
      <input type="number" placeholder={l.baseSalary} onChange={e => setData({ ...data, base: parseFloat(e.target.value) })} />
      <input type="number" placeholder={l.electricity} onChange={e => setData({ ...data, electricity: parseFloat(e.target.value) })} />
      <input type="number" placeholder={l.gas} onChange={e => setData({ ...data, gas: parseFloat(e.target.value) })} />
      <input type="number" placeholder={l.housing} onChange={e => setData({ ...data, housing: parseFloat(e.target.value) })} />
      <button onClick={handleCalc}>{l.calculate}</button>
      {result && (
        <div>
          <h2>{l.result}</h2>
          <p>{l.tax}: ₩{result.tax.toFixed(0)}</p>
          <p>{l.safety}: ₩{result.safety.toFixed(0)}</p>
          <p>{l.net}: ₩{result.net.toFixed(0)}</p>
        </div>
      )}
      <div style={{ marginTop: '30px', textAlign: 'center' }}>
        <img src="/flags/egypt.png" alt="Egypt" width="50" />
        <img src="/flags/yemen.png" alt="Yemen" width="50" />
        <img src="/flags/south-korea.png" alt="Korea" width="50" />
        <img src="/hyundai-samho-logo.png" alt="Hyundai Samho" width="120" />
      </div>
      <div style={{ marginTop: '20px', textAlign: 'center', fontWeight: 'bold', fontSize: '20px', color: 'red' }}>
        إهداء من محمود بيه المصري
      </div>
    </div>
  );
}
